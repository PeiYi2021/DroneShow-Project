import os

import bpy
import mathutils
import math
import gc

from bpy_extras.io_utils import ExportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty
from bpy.types import Operator

import time

bl_info = {
    "name": "Drones add-on",
    "blender": (2, 80, 0),
    "category": "Import-Export",
}


def _working_fragment_is_valid(scene):
    return 0 <= scene.custom_frame_start <= scene.frame_end and 0 <= scene.custom_frame_end <= scene.frame_end and scene.custom_frame_start < scene.custom_frame_end


def _get_uav_locations(op, scene):
    start_time = time.time()
    uav_loc = dict()
    for obj in bpy.data.objects:
        if obj.name.find(scene.custom_uav_prefix) == 0:
            if obj.name[len(scene.custom_uav_prefix):].isdigit():
                uav_loc[obj.name] = dict()
    if len(uav_loc) > 0:
        for f in range(scene.custom_frame_start, scene.custom_frame_end):
            scene.frame_set(f)
            # iterate through every object
            for obj in bpy.data.objects:
                if obj.name in uav_loc:
                    uav_loc[obj.name][f] = [obj.matrix_world.to_translation().x,
                                            obj.matrix_world.to_translation().y,
                                            obj.matrix_world.to_translation().z]
        op.report(type={'INFO'},
                  message='gathered locations in {:3.2f} sec'.format(time.time() - start_time))
    return uav_loc


class SCENE_PT_SpeedTestItem(bpy.types.PropertyGroup):
    frame: bpy.props.StringProperty(name="Frame", default="Unknown")
    text: bpy.props.StringProperty(name="Text", default="Unknown")
    speed: bpy.props.FloatProperty(name="Speed", default=0.0)


class LIST_UL_Speed(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            split = layout.split(factor=0.2)
            split.label(text=item.frame)
            split.label(text=item.text)
            split.label(text=str(item.speed))

        elif self.layout_type in {'GRID'}:
            pass


class OBJECT_OT_check_speed(bpy.types.Operator):
    bl_idname = "object.check_speed"
    bl_label = "Check Speed"
    bl_options = {'REGISTER'}

    counter = 1

    def execute(self, context):
        scene = context.scene
        scale = scene.custom_scale
        pos_fps = int(scene.custom_pos_frame_rate)

        if not _working_fragment_is_valid(scene):
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='Invalid working fragment')
            return {"CANCELLED"}

        speed_list = scene.custom_speed_list
        speed_list.clear()

        uav_locations = _get_uav_locations(self, scene)
        if len(uav_locations) == 0:
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='No objects have been found with the specified prefix')
            return {"CANCELLED"}

        start_time = time.time()
        for uav in uav_locations:
            for f in range(scene.custom_frame_start + 1, scene.custom_frame_end):
                if not ((f - 1) % (scene.custom_blender_frame_rate / pos_fps) == 0):
                    continue
                l_x = uav_locations[uav][f - 1][0] * scale
                l_y = uav_locations[uav][f - 1][1] * scale
                l_z = uav_locations[uav][f - 1][2] * scale
                x = uav_locations[uav][f][0] * scale
                y = uav_locations[uav][f][1] * scale
                z = uav_locations[uav][f][2] * scale
                dx = x - l_x
                dy = y - l_y
                dz = z - l_z
                d = math.sqrt(dx * dx + dy * dy)
                s = d * scene.custom_blender_frame_rate
                if s >= scene.custom_speed_hor_thresh:
                    speed_item = speed_list.add()
                    speed_item.id = self.counter
                    self.counter += 1
                    speed_item.frame = str(f)
                    speed_item.text = "Hor [" + uav + "]"
                    speed_item.speed = s
                s = dz * scene.custom_blender_frame_rate
                if (s > 0) and (s >= scene.custom_speed_up_thresh):
                    speed_item = speed_list.add()
                    speed_item.id = self.counter
                    self.counter += 1
                    speed_item.frame = str(f)
                    speed_item.text = "Asc [" + uav + "]"
                    speed_item.speed = s
                if (s < 0) and (-s >= scene.custom_speed_dn_thresh):
                    speed_item = speed_list.add()
                    speed_item.id = self.counter
                    self.counter += 1
                    speed_item.frame = str(f)
                    speed_item.text = "Desc [" + uav + "]"
                    speed_item.speed = s

        del uav_locations
        gc.collect()

        self.report(type={'INFO'},
                    message='successfully checked velocity in {:3.2f} sec'.format(time.time() - start_time))
        return {'FINISHED'}

def _clear_UAV_selection(scene):
    for obj in bpy.data.objects:
        if obj.name.find(scene.custom_uav_prefix) == 0:
            if obj.name[len(scene.custom_uav_prefix):].isdigit():
                obj.select_set(state=False)



def _update_collision_idx(self, context):
    idx = self.custom_collision_idx
    frame = int(self.custom_collision_list[idx].frame)
    self.frame_set(frame)
    # clear selection of all UAVs
    _clear_UAV_selection(context.scene)
    # set selection state for first UAV selected in list
    name_1, name_2 = self.custom_collision_list[idx].text.split(" and ")
    ob_1 = bpy.data.objects[name_1]
    ob_2 = bpy.data.objects[name_2]
    ob_1.select_set(state=True)
    ob_2.select_set(state=True)
    bpy.context.view_layer.objects.active = ob_1

def _update_speed_idx(self, context):
    idx = self.custom_speed_idx
    frame = int(self.custom_speed_list[idx].frame)
    self.frame_set(frame)
    # clear selection of all UAVs
    _clear_UAV_selection(context.scene)
    # set selection state for UAV selected in list
    ob = bpy.data.objects[self.custom_speed_list[idx].text]
    ob.select_set(state=True)
    bpy.context.view_layer.objects.active = ob

class SCENE_PT_CollisionTestItem(bpy.types.PropertyGroup):
    frame: bpy.props.StringProperty(name="Frame", default="Unknown")
    text: bpy.props.StringProperty(name="Text", default="Unknown")
    dist: bpy.props.StringProperty(name="Dist", default="Unknown")


class LIST_UL_Collisions(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            split = layout.split(factor=0.2)
            split.label(text=item.frame)
            split.label(text=item.text)
            split.label(text=item.dist)

        elif self.layout_type in {'GRID'}:
            pass


class OBJECT_OT_check_collisions(bpy.types.Operator):
    bl_idname = "object.check_collisions"
    bl_label = "Check Collisions"
    bl_options = {'REGISTER'}

    collision_counter = 0

    def execute(self, context):
        scene = context.scene
        scale = scene.custom_scale
        pos_fps = int(scene.custom_pos_frame_rate)

        if not _working_fragment_is_valid(scene):
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='Invalid working fragment')
            return {"CANCELLED"}

        collision_list = scene.custom_collision_list
        collision_list.clear()

        uav_locations = _get_uav_locations(self, scene)
        if len(uav_locations) == 0:
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='No objects have been found with the specified prefix')
            return {"CANCELLED"}
        uav_list = list(uav_locations.keys())

        start_time = time.time()
        threshold_square = scene.custom_dist_thresh * scene.custom_dist_thresh
        ll = len(uav_list)
        frames = []

        for f in range(scene.custom_frame_start, scene.custom_frame_end):
            if (f - 1) % (scene.custom_blender_frame_rate / pos_fps) == 0:
                frames.append(f)

        for i, uav_i in enumerate(uav_list):
            u_loc_i = uav_locations[uav_i]
            for j in range(i + 1, ll):
                uav_j = uav_list[j]
                u_loc_j = uav_locations[uav_j]
                for f in frames:
                    u_i = u_loc_i[f]
                    u_j = u_loc_j[f]
                    dx = u_j[0] * scale - u_i[0] * scale
                    dy = u_j[1] * scale - u_i[1] * scale
                    dz = u_j[2] * scale - u_i[2] * scale
                    d = dx * dx + dy * dy + dz * dz
                    if d < threshold_square:
                        collision_item = collision_list.add()
                        collision_item.id = self.collision_counter
                        self.collision_counter += 1
                        collision_item.frame = str(f)
                        collision_item.text = '{} and {}'.format(uav_i, uav_j)
                        collision_item.dist = str(round(math.sqrt(d), 2))
        del uav_list
        del frames
        del uav_locations

        gc.collect()
        self.report(type={'INFO'},
                    message='successfully checked collisions in {:3.2f} sec'.format(time.time() - start_time))
        return {'FINISHED'}


def _export_legacy(filepath, idx, pos, col, scale):
    if not os.path.isdir(filepath):
        os.makedirs(filepath)
    with open(os.path.join(filepath, 'DSS-' + str(idx) + '.PATH'), 'wb') as f:
        for p, c in zip(pos, col):
            x, y, z = p
            r, g, b = c
            f.write(int(x * scale).to_bytes(2, byteorder='little', signed=True))
            f.write(int(y * scale).to_bytes(2, byteorder='little', signed=True))
            f.write(int(z * scale).to_bytes(2, byteorder='little', signed=True))
            f.write((r).to_bytes(2, byteorder='little', signed=True))
            f.write((g).to_bytes(2, byteorder='little', signed=True))
            f.write((b).to_bytes(2, byteorder='little', signed=True))


def _export_v3(filepath, idx, pos, col, scale, pos_frame_rate, col_frame_rate):
    # write header
    if not os.path.isdir(filepath):
        os.makedirs(filepath)
    with open(os.path.join(filepath, 'DSS-' + str(idx) + '.PATH3'), 'wb') as f:
        # l = <- for supress blender console output
        l = f.write("DP".encode())  # magic bytes
        l = f.write((3).to_bytes(1, byteorder='little', signed=True))  # format version
        l = f.write((14).to_bytes(1, byteorder='little', signed=True))  # header size
        l = f.write(
            (0).to_bytes(4, byteorder='little', signed=True))  # crc. if zero it will be calculated in DSS Client later
        l = f.write((0).to_bytes(2, byteorder='little', signed=True))  # reserved
        l = f.write(int(scale * 10).to_bytes(2, byteorder='little',
                                             signed=False))  # millmeteres in unit (so we multiply by ten). Here is one unit = 10 millimeters
        l = f.write(
            (2).to_bytes(1, byteorder='little', signed=True))  # section count (we have two: position and colors)
        l = f.write((8).to_bytes(1, byteorder='little', signed=True))  # section header size
        # section 1 header
        l = f.write((1).to_bytes(1, byteorder='little', signed=True))  # section type 1 means positions
        l = f.write((0).to_bytes(1, byteorder='little', signed=True))  # reserved
        l = f.write((pos_frame_rate * 1000).to_bytes(2, byteorder='little', signed=False))  # section FPS
        l = f.write((len(pos) * 6).to_bytes(4, byteorder='little',
                                            signed=False))  # section size in bytes. 6 is the size of block: 2bytes * 3coordinates.
        # section 2 header
        l = f.write((2).to_bytes(1, byteorder='little', signed=True))  # section type 2 means colors
        l = f.write((0).to_bytes(1, byteorder='little', signed=True))  # reserved
        l = f.write((col_frame_rate * 1000).to_bytes(2, byteorder='little', signed=False))  # section FPS
        l = f.write((len(col) * 3).to_bytes(4, byteorder='little',
                                            signed=False))  # section size in bytes. 3 is the size of block: 1byte * 3values.
        # fill section 1 with positions
        for p in pos:
            for x in p:
                l = f.write(int(x).to_bytes(2, byteorder='little', signed=True))
        # fill section 2 with colors
        for c in col:
            for x in c:
                if x > 255:
                    x = 255
                l = f.write((x).to_bytes(1, byteorder='little', signed=False))  # unsigned!


class OBJECT_OT_export_paths(bpy.types.Operator, ExportHelper):
    bl_idname = "object.export_paths"
    bl_label = "Export Paths"
    bl_options = {'REGISTER'}

    filename_ext = ""

    filter_glob: StringProperty(
        default="*",
        options={'HIDDEN'},
        maxlen=255,  # Max internal buffer length, longer would be clamped.
    )

    format_revision: EnumProperty(
        name="Format revision",
        description="Choose between two items",
        items=(
            ('OPT_legacy', "Current", "Exports .PATH format"),
            ('OPT_v3', "New", "Exports .PATH3 format"),
        ),
        default='OPT_legacy',
    )

    def execute(self, context):
        scene = context.scene
        scale = scene.custom_scale
        pos_fps = int(scene.custom_pos_frame_rate)
        col_fps = int(scene.custom_col_frame_rate)

        pos = list()  # array of uavs and coordinates
        col = list()  # array of uavs and colors
        uav_list = list()

        if not _working_fragment_is_valid(scene):
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='Invalid working fragment')
            return {"CANCELLED"}

        if scene.custom_blender_frame_rate == 0 \
                or pos_fps == 0 \
                or col_fps == 0:
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='Framerates cannot be set to zero')
            return {"CANCELLED"}
        if (scene.custom_blender_frame_rate % pos_fps) != 0:
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='Position FPS must be a divisor of blender FPS')
            return {"CANCELLED"}
        if (scene.custom_blender_frame_rate % col_fps) != 0:
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='Color FPS must be a divisor of blender FPS')
            return {"CANCELLED"}

        for i, obj in enumerate(bpy.data.objects):
            if obj.name.find(scene.custom_uav_prefix) == 0:
                if obj.name[len(scene.custom_uav_prefix):].isdigit():
                    pos.append([])
                    col.append([])
                    uav_list.append(obj.name)

        uav_list = sorted(uav_list, key=lambda x: int(x[len(scene.custom_uav_prefix):]))
        uav_indices = [int(x[len(scene.custom_uav_prefix):]) for x in uav_list]

        if len(uav_list) == 0:
            self.report(type={'ERROR_INVALID_INPUT'},
                        message='No objects have been found with the specified prefix')
            return {"CANCELLED"}

        for f in range(scene.custom_frame_start, scene.custom_frame_end):
            save_position = ((f - 1) % (scene.custom_blender_frame_rate // pos_fps) == 0)
            save_color = ((f - 1) % (scene.custom_blender_frame_rate // col_fps) == 0)
            if save_position or save_color:
                scene.frame_set(f)
                for i, uav in enumerate(uav_list):
                    obj = bpy.data.objects[uav]
                    if save_position:
                        p = [0.0, 0.0, 0.0]
                        # get position from blender scene and convert it to centimeters
                        p[0] = obj.matrix_world.to_translation()[0] * 100
                        p[1] = obj.matrix_world.to_translation()[1] * 100
                        p[2] = obj.matrix_world.to_translation()[2] * 100
                        pos[i].append(p)
                        if self.format_revision == 'OPT_legacy':
                            if ((abs(p[0] * scale) > 32767) or (abs(p[1] * scale) > 32767) or (abs(p[2] * scale) > 32767)):
                                self.report(type={'ERROR_INVALID_INPUT'}, message='Show is greater than 327 meters. Please decrease scale. ' + str((p[0] * scale)) + ", "+ str((p[1] * scale)) + ", "+ str((p[2] * scale)))
                                return {"CANCELLED"}
                    if save_color:
                        c = [0, 0, 0]
                        if not scene.custom_emission_shader:
                            # get colors from blender scene and convert it from float[0,1] to int[0,255] interval
                            #mat = obj.active_material
                            #node = mat.node_tree.nodes.get('Shader to RGB')
                            #r, g, b = node.outputs['Color'].default_value
                            #c[0] = r * scene.max_led_value
                            #c[1] = g * scene.max_led_value
                            #c[2] = b * scene.max_led_value
                            c[0] = int(obj.active_material.diffuse_color[0] * scene.max_led_value)
                            c[1] = int(obj.active_material.diffuse_color[1] * scene.max_led_value)
                            c[2] = int(obj.active_material.diffuse_color[2] * scene.max_led_value)
                        else:

                            if 'Emission' not in obj.active_material.node_tree.nodes:
                                self.report(type={'ERROR_INVALID_INPUT'}, message='You need to select "Emission" surface in Material Properties->Surface panel to use this option. Also, make sure you set the color using this panel.')
                                return {"CANCELLED"}

                            c = list(obj.active_material.node_tree.nodes['Emission'].inputs['Color'].default_value[0:3])
                            s = 1

                            if scene.custom_emission_shader_use_strength:
                                s = float(obj.active_material.node_tree.nodes['Emission'].inputs['Strength'].default_value)
                                s = min(s, 1.0)

                            c[0] = int(c[0] * scene.max_led_value * s)
                            c[1] = int(c[1] * scene.max_led_value * s)
                            c[2] = int(c[2] * scene.max_led_value * s)

                        col[i].append(c)

        for i, p, c in zip(uav_indices, pos, col):
            if self.format_revision == 'OPT_v3':
                _export_v3(filepath=self.filepath, idx=i, pos=p, col=c,
                           scale=scale,
                           pos_frame_rate=pos_fps,
                           col_frame_rate=col_fps)
            elif self.format_revision == 'OPT_legacy':
                if len(p) > 2000 or len(c) > 2000:
                    self.report(type={'ERROR_INVALID_INPUT'},
                                message='Unable to export more than 2000 points, file size limit exceeded')
                    return {"CANCELLED"}
                _export_legacy(self.filepath, i, p, c, scale)
        self.report(type={'INFO'},
                    message='successfully exported files')
        return {'FINISHED'}


class LayoutDemoPanel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_label = 'DSS'
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row()
        row.prop(scene, "custom_uav_prefix")

        layout.separator_spacer()

        layout.label(text="Working Segment:")
        row = layout.row()
        row.prop(scene, "custom_frame_start")
        row.prop(scene, "custom_frame_end")

        layout.separator_spacer()

        layout.label(text="Dance Settings:")
        row = layout.row()
        row.prop(scene, "custom_blender_frame_rate")
        row.prop(scene, "custom_scale")

        row = layout.row()
        row.prop(scene, "custom_pos_frame_rate")

        row = layout.row()
        row.prop(scene, "custom_col_frame_rate")

        row = layout.row()
        row.prop(scene, "max_led_value", slider=True)

        layout.separator_spacer()

        row = layout.row()
        row.prop(scene, "custom_speed_hor_thresh")
        row.prop(scene, "custom_speed_up_thresh")
        row.prop(scene, "custom_speed_dn_thresh")
        layout.template_list("LIST_UL_Speed", "", scene, "custom_speed_list", scene, "custom_speed_idx")

        row = layout.row()
        row.prop(scene, "custom_dist_thresh")
        layout.template_list("LIST_UL_Collisions", "", scene, "custom_collision_list", scene, "custom_collision_idx")

        row = layout.row()
        row.prop(scene, "custom_emission_shader")

        if scene.custom_emission_shader:
            row = layout.row()
            row.prop(scene, "custom_emission_shader_use_strength")

        row = layout.row()
        row.scale_y = 2.0        

        row.operator("object.check_collisions")
        row.operator("object.check_speed")
        row.operator("object.export_paths")


def _get_divisors(n):
    for i in range(1, n // 2 + 1):
        if n % i == 0:
            yield i
    yield n


def _update_fps_enum(self, context):
    print('update enum')
    return None


def _get_fps_enum_item_id(d):
    if d == 4:
        return 0
    return d


def _get_fps_enum(self, context):
    divs = list(_get_divisors(self.custom_blender_frame_rate))
    # _get_fps_enum_item_id is need for setting first default value. The only way to
    # set default value is to set id=0 for it.
    # UPDATE: this trick with id=0 doesn't work in 2.80 anymore 
    items = [(str(d), str(d), "", _get_fps_enum_item_id(d)) for d in divs]
    return items


def register_properties():
    bpy.types.Scene.custom_uav_prefix = bpy.props.StringProperty(name="UAV Prefix")
    bpy.types.Scene.custom_frame_start = bpy.props.IntProperty(name="Working Frame Start",
                                                               soft_min=0)
                                                               # soft_max=bpy.context.scene.frame_end)
    bpy.types.Scene.custom_frame_end = bpy.props.IntProperty(name="Working Frame End",
                                                             soft_min=0)
                                                             # soft_max=bpy.context.scene.frame_end,
                                                             # default=bpy.context.scene.frame_end)
    bpy.types.Scene.custom_blender_frame_rate = bpy.props.IntProperty(name="Blender FPS", soft_min=0, default=24)
    bpy.types.Scene.custom_pos_frame_rate = bpy.props.EnumProperty(
        name="Position FPS",
        description="",
        items=_get_fps_enum,
        default=None,
        update=_update_fps_enum
    )

    bpy.types.Scene.custom_col_frame_rate = bpy.props.EnumProperty(
        name="Color FPS",
        description="",
        items=_get_fps_enum,
        default=None,
        update=_update_fps_enum
    )
    bpy.types.Scene.custom_scale = bpy.props.FloatProperty(name="Scale", default=1.)

    bpy.types.Scene.max_led_value = bpy.props.FloatProperty(name="Max Led Value", default=255, min=0.0, max=255, step=1, precision=1)

    bpy.types.Scene.custom_speed_hor_thresh = bpy.props.FloatProperty(name="Horizontal Velocity threshold", default=3.)
    bpy.types.Scene.custom_speed_up_thresh = bpy.props.FloatProperty(name="Ascend Velocity threshold", default=2.5)
    bpy.types.Scene.custom_speed_dn_thresh = bpy.props.FloatProperty(name="Descend Velocity threshold", default=1.5)
    bpy.types.Scene.custom_dist_thresh = bpy.props.FloatProperty(name="Distance threshold", default=2.49)

    bpy.types.Scene.custom_speed_idx = bpy.props.IntProperty(name="custom_speed_idx", update=_update_speed_idx)
    bpy.types.Scene.custom_collision_idx = bpy.props.IntProperty(name="custom_collision_idx",
                                                                 update=_update_collision_idx)

    bpy.types.Scene.custom_emission_shader = bpy.props.BoolProperty(name='Use Emission shader', default=False)
    bpy.types.Scene.custom_emission_shader_use_strength = bpy.props.BoolProperty(name='Use Strength parameter', default=True)


def register():
    register_properties()
    bpy.utils.register_class(LayoutDemoPanel)
    bpy.utils.register_class(OBJECT_OT_export_paths)
    bpy.utils.register_class(OBJECT_OT_check_speed)
    bpy.utils.register_class(OBJECT_OT_check_collisions)
    bpy.utils.register_class(SCENE_PT_SpeedTestItem)
    bpy.utils.register_class(SCENE_PT_CollisionTestItem)
    bpy.utils.register_class(LIST_UL_Speed)
    bpy.utils.register_class(LIST_UL_Collisions)
    bpy.types.Scene.custom_speed_list = bpy.props.CollectionProperty(type=SCENE_PT_SpeedTestItem, name="TEST")
    bpy.types.Scene.custom_collision_list = bpy.props.CollectionProperty(type=SCENE_PT_CollisionTestItem, name="TEST2")



def unregister():
    bpy.utils.unregister_class(LayoutDemoPanel)
    bpy.utils.unregister_class(OBJECT_OT_export_paths)
    bpy.utils.unregister_class(OBJECT_OT_check_speed)
    bpy.utils.unregister_class(OBJECT_OT_check_collisions)
    bpy.utils.unregister_class(SCENE_PT_SpeedTestItem)
    bpy.utils.unregister_class(SCENE_PT_CollisionTestItem)
    bpy.utils.unregister_class(LIST_UL_Speed)
    bpy.utils.unregister_class(LIST_UL_Collisions)


if __name__ == "__main__":
    register()
